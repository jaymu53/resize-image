from .resize import main
main()

