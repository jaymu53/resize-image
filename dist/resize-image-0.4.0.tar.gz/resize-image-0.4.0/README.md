# Resize an Image given width and height

## Usage:

### pip install resize-image
### resize-image --image pathToImage --width width --height height --destination pathToDestination

